export * from './fade-in.animation';
export * from './slide-in-out.animation';
// source for this whole folder "_animations": http://jasonwatmore.com/post/2017/04/19/angular-2-4-router-animation-tutorial-example